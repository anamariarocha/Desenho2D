/* Javascript - app.js */
const app = {
    init: function() {
        this.canvas = document.querySelector("canvas");
        this.ctx = this.canvas.getContext("2d");
        
        this.d1 = new Forma2d();
        for(let i = 0; i < 5; i++) {
            this.d1.vertices.push({x: parseInt(Math.random()*100), y: parseInt(Math.random()*100)});
        }
        //this.d1.vertices.push({x: 20, y: 10});
        //this.d1.vertices.push({x: 100, y: 10});
        //this.d1.vertices.push({x: 110, y: 90});
        //this.d1.vertices.push({x: 10, y: 90});
        this.d1.fill = "red";
        this.d1.stroke = "black";
        
        //Eventos
        document.querySelector("#zoomIn").onclick = () => {
            this.d1.scale(1.05);
            this.render();
        };
        document.querySelector("#zoomOut").onclick = () => {
            this.d1.scale(0.95);
            this.render();
        };
        document.querySelector("#rotate1").onclick = () => {
            this.d1.rotate(5);
            this.render();
        };
        document.querySelector("#rotate2").onclick = () => {
            this.d1.rotate(-5);
            this.render();
        };
        this.d1.renderiza(this.ctx);
    },
    
    render: function() {
        this.ctx.fillStyle = "white";
        this.ctx.fillRect(0,0,720,480);
        this.d1.renderiza(this.ctx);
    }
};
window.onload = () => app.init();
