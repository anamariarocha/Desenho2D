/* Javascript - Forma2d.js */
class Forma2d {
    constructor() {
        this.vertices = [];
        this.fill = "blue";
        this.stroke = "green";
    }
    renderiza(ctx) {
        ctx.fillStyle = this.fill;
        ctx.strokeStyle = this.stroke;
        ctx.beginPath();
        ctx.moveTo(this.vertices[0].x,this.vertices[0].y);
        for(let vertice of this.vertices) {
            ctx.lineTo(vertice.x, vertice.y);
        }
        ctx.closePath();
        ctx.fill();
        ctx.stroke();
    }
    midPoint() {
        let mid = {x: 0, y: 0};
        for(let vertice of this.vertices) {
            mid.x += vertice.x;
            mid.y += vertice.y;
        }
        mid.x /= this.vertices.length;
        mid.y /= this.vertices.length;
        return mid;
    }
    translate(x, y) {
        for(let vertice of this.vertices) {
            vertice.x += x;
            vertice.y += y;
        }
    }
    scale(s) {
        //Obtém o ponto médio
        let m = this.midPoint();
        //Faz a translação para o ponto 0,0
        this.translate(-m.x, -m.y);
        //Faz a escala
        for(let vertice of this.vertices) {
            vertice.x *= s;
            vertice.y *= s;
        }
        //Faz a translação para o ponto médio
        this.translate(m.x, m.y);
    }
    rotate(theta) {
        //Obtém o ponto médio
        let m = this.midPoint();
        //Faz a translação para o ponto 0,0
        this.translate(-m.x, -m.y);
        //Converte graus para radianos
        theta = theta * Math.PI / 180;
        //Faz a rotação
        for(let vertice of this.vertices) {
            let x = vertice.x * Math.cos(theta) - vertice.y * Math.sin(theta);
            let y = vertice.y * Math.cos(theta) + vertice.x * Math.sin(theta);
            vertice.x = x;
            vertice.y = y;
        }
        //Faz a translação para o ponto médio
        this.translate(m.x, m.y);
    }
}
